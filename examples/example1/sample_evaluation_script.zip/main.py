import random
import sys
import traceback

def evaluate(test_annotation_file ,user_annotation_file, phase_name, **kwargs):

    print "Loading Test annotation file ..."
    with open(test_annotation_file, "r") as f:
        # Do stuff here
        print "Successfully loaded the test annotation file"

    print "Loading User annotation file ..."
    with open(user_annotation_file, "r") as f:
        # Do stuff here
        print "Successfully loaded the User annotation file"

    result = {}
    try:
        result['result'] = [
            {
                'split1': {
                    'score': random.random(),
                }
            },
            {
                'split2': {
                    'score': random.random(),
                }
            }
        ]
        result['submission_metadata'] = "This submission metadata will only be shown to the Challenge Host"
        result['submission_result'] = "This is the actual result to show to the participant once submission is finished"
        return result
    except Exception as e:
        sys.stderr.write(traceback.format_exc())
        return e
