--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4 (Debian 10.4-2.pgdg90+1)
-- Dumped by pg_dump version 12.2 (Debian 12.2-2.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO postgres;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO postgres;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO postgres;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO postgres;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: accounts_userstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_userstatus (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(30) NOT NULL,
    status character varying(30) NOT NULL
);


ALTER TABLE public.accounts_userstatus OWNER TO postgres;

--
-- Name: accounts_userstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_userstatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_userstatus_id_seq OWNER TO postgres;

--
-- Name: accounts_userstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_userstatus_id_seq OWNED BY public.accounts_userstatus.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: challenge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    terms_and_conditions text,
    submission_guidelines text,
    evaluation_details text,
    image character varying(100),
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    published boolean NOT NULL,
    enable_forum boolean NOT NULL,
    anonymous_leaderboard boolean NOT NULL,
    creator_id integer NOT NULL,
    is_disabled boolean NOT NULL,
    evaluation_script character varying(100) NOT NULL,
    approved_by_admin boolean NOT NULL,
    short_description text,
    featured boolean NOT NULL,
    allowed_email_domains character varying(50)[] NOT NULL,
    blocked_email_domains character varying(50)[] NOT NULL,
    forum_url character varying(100),
    remote_evaluation boolean NOT NULL,
    queue character varying(200) NOT NULL,
    is_docker_based boolean NOT NULL,
    slug character varying(200),
    max_docker_image_size bigint,
    leaderboard_description text,
    max_concurrent_submission_evaluation integer NOT NULL,
    aws_access_key_id character varying(200),
    aws_account_id character varying(200),
    aws_region character varying(50),
    aws_secret_access_key character varying(200),
    use_host_credentials boolean NOT NULL,
    cli_version character varying(20),
    is_registration_open boolean NOT NULL,
    banned_email_ids text[],
    task_def_arn character varying(2048),
    workers integer,
    slack_webhook_url character varying(200),
    CONSTRAINT challenge_max_concurrent_submission_evaluation_check CHECK ((max_concurrent_submission_evaluation >= 0))
);


ALTER TABLE public.challenge OWNER TO postgres;

--
-- Name: challenge_evaluation_cluster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_evaluation_cluster (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(200) NOT NULL,
    cluster_yaml character varying(100) NOT NULL,
    kube_config character varying(100),
    challenge_id integer NOT NULL
);


ALTER TABLE public.challenge_evaluation_cluster OWNER TO postgres;

--
-- Name: challenge_evaluation_cluster_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_evaluation_cluster_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_evaluation_cluster_id_seq OWNER TO postgres;

--
-- Name: challenge_evaluation_cluster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_evaluation_cluster_id_seq OWNED BY public.challenge_evaluation_cluster.id;


--
-- Name: challenge_host; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_host (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    status character varying(30) NOT NULL,
    permissions character varying(30) NOT NULL,
    team_name_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.challenge_host OWNER TO postgres;

--
-- Name: challenge_host_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_host_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_host_id_seq OWNER TO postgres;

--
-- Name: challenge_host_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_host_id_seq OWNED BY public.challenge_host.id;


--
-- Name: challenge_host_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_host_teams (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    team_name character varying(100) NOT NULL,
    created_by_id integer NOT NULL,
    team_url character varying(1000) NOT NULL
);


ALTER TABLE public.challenge_host_teams OWNER TO postgres;

--
-- Name: challenge_host_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_host_teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_host_teams_id_seq OWNER TO postgres;

--
-- Name: challenge_host_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_host_teams_id_seq OWNED BY public.challenge_host_teams.id;


--
-- Name: challenge_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_id_seq OWNER TO postgres;

--
-- Name: challenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_id_seq OWNED BY public.challenge.id;


--
-- Name: challenge_participant_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_participant_teams (
    id integer NOT NULL,
    challenge_id integer NOT NULL,
    participantteam_id integer NOT NULL
);


ALTER TABLE public.challenge_participant_teams OWNER TO postgres;

--
-- Name: challenge_participant_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_participant_teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_participant_teams_id_seq OWNER TO postgres;

--
-- Name: challenge_participant_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_participant_teams_id_seq OWNED BY public.challenge_participant_teams.id;


--
-- Name: challenge_phase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_phase (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    leaderboard_public boolean NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    test_annotation character varying(100) NOT NULL,
    challenge_id integer NOT NULL,
    max_submissions integer NOT NULL,
    max_submissions_per_day integer NOT NULL,
    is_public boolean NOT NULL,
    codename character varying(100) NOT NULL,
    is_submission_public boolean NOT NULL,
    max_concurrent_submissions_allowed integer NOT NULL,
    max_submissions_per_month integer NOT NULL,
    allowed_email_ids text[],
    slug character varying(200),
    environment_image character varying(2128),
    allowed_submission_file_types character varying(200) NOT NULL,
    is_restricted_to_select_one_submission boolean NOT NULL,
    CONSTRAINT challenge_phase_max_concurrent_submissions_allowed_check CHECK ((max_concurrent_submissions_allowed >= 0)),
    CONSTRAINT challenge_phase_max_submissions_check CHECK ((max_submissions >= 0)),
    CONSTRAINT challenge_phase_max_submissions_per_day_check CHECK ((max_submissions_per_day >= 0)),
    CONSTRAINT challenge_phase_max_submissions_per_month_check CHECK ((max_submissions_per_month >= 0))
);


ALTER TABLE public.challenge_phase OWNER TO postgres;

--
-- Name: challenge_phase_split; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_phase_split (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    visibility smallint NOT NULL,
    challenge_phase_id integer NOT NULL,
    dataset_split_id integer NOT NULL,
    leaderboard_id integer NOT NULL,
    is_leaderboard_order_descending boolean NOT NULL,
    leaderboard_decimal_precision integer NOT NULL,
    show_leaderboard_by_latest_submission boolean NOT NULL,
    CONSTRAINT challenge_phase_split_leaderboard_decimal_precision_check CHECK ((leaderboard_decimal_precision >= 0)),
    CONSTRAINT challenge_phase_split_visibility_b353220c_check CHECK ((visibility >= 0))
);


ALTER TABLE public.challenge_phase_split OWNER TO postgres;

--
-- Name: challenge_phase_split_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_phase_split_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_phase_split_id_seq OWNER TO postgres;

--
-- Name: challenge_phase_split_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_phase_split_id_seq OWNED BY public.challenge_phase_split.id;


--
-- Name: challenge_test_env_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_test_env_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_test_env_id_seq OWNER TO postgres;

--
-- Name: challenge_test_env_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_test_env_id_seq OWNED BY public.challenge_phase.id;


--
-- Name: challenge_zip_configuration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challenge_zip_configuration (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    zip_configuration character varying(100) NOT NULL,
    is_created boolean NOT NULL,
    stdout_file character varying(100),
    stderr_file character varying(100),
    challenge_id integer,
    user_id integer NOT NULL
);


ALTER TABLE public.challenge_zip_configuration OWNER TO postgres;

--
-- Name: challenge_zip_configuration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.challenge_zip_configuration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.challenge_zip_configuration_id_seq OWNER TO postgres;

--
-- Name: challenge_zip_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.challenge_zip_configuration_id_seq OWNED BY public.challenge_zip_configuration.id;


--
-- Name: contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(70) NOT NULL,
    message character varying(500) NOT NULL,
    status character varying(30) NOT NULL
);


ALTER TABLE public.contact OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_id_seq OWNER TO postgres;

--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: dataset_split; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dataset_split (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    name character varying(100) NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.dataset_split OWNER TO postgres;

--
-- Name: dataset_split_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dataset_split_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dataset_split_id_seq OWNER TO postgres;

--
-- Name: dataset_split_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dataset_split_id_seq OWNED BY public.dataset_split.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_ses_sesstat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_ses_sesstat (
    id integer NOT NULL,
    date date NOT NULL,
    delivery_attempts integer NOT NULL,
    bounces integer NOT NULL,
    complaints integer NOT NULL,
    rejects integer NOT NULL,
    CONSTRAINT django_ses_sesstat_bounces_check CHECK ((bounces >= 0)),
    CONSTRAINT django_ses_sesstat_complaints_check CHECK ((complaints >= 0)),
    CONSTRAINT django_ses_sesstat_delivery_attempts_check CHECK ((delivery_attempts >= 0)),
    CONSTRAINT django_ses_sesstat_rejects_check CHECK ((rejects >= 0))
);


ALTER TABLE public.django_ses_sesstat OWNER TO postgres;

--
-- Name: django_ses_sesstat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_ses_sesstat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_ses_sesstat_id_seq OWNER TO postgres;

--
-- Name: django_ses_sesstat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_ses_sesstat_id_seq OWNED BY public.django_ses_sesstat.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: invite_user_to_challenge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite_user_to_challenge (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    email character varying(200) NOT NULL,
    invitation_key character varying(200) NOT NULL,
    status character varying(30) NOT NULL,
    challenge_id integer NOT NULL,
    invited_by_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.invite_user_to_challenge OWNER TO postgres;

--
-- Name: invite_user_to_challenge_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invite_user_to_challenge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invite_user_to_challenge_id_seq OWNER TO postgres;

--
-- Name: invite_user_to_challenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invite_user_to_challenge_id_seq OWNED BY public.invite_user_to_challenge.id;


--
-- Name: leaderboard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaderboard (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    schema jsonb NOT NULL
);


ALTER TABLE public.leaderboard OWNER TO postgres;

--
-- Name: leaderboard_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaderboard_data (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    result jsonb NOT NULL,
    challenge_phase_split_id integer NOT NULL,
    leaderboard_id integer NOT NULL,
    submission_id integer NOT NULL,
    error jsonb
);


ALTER TABLE public.leaderboard_data OWNER TO postgres;

--
-- Name: leaderboard_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leaderboard_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leaderboard_data_id_seq OWNER TO postgres;

--
-- Name: leaderboard_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leaderboard_data_id_seq OWNED BY public.leaderboard_data.id;


--
-- Name: leaderboard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leaderboard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leaderboard_id_seq OWNER TO postgres;

--
-- Name: leaderboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leaderboard_id_seq OWNED BY public.leaderboard.id;


--
-- Name: participant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participant (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    status character varying(30) NOT NULL,
    user_id integer NOT NULL,
    team_id integer
);


ALTER TABLE public.participant OWNER TO postgres;

--
-- Name: participant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.participant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participant_id_seq OWNER TO postgres;

--
-- Name: participant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.participant_id_seq OWNED BY public.participant.id;


--
-- Name: participant_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participant_team (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    team_name character varying(100) NOT NULL,
    created_by_id integer,
    team_url character varying(1000) NOT NULL
);


ALTER TABLE public.participant_team OWNER TO postgres;

--
-- Name: participant_team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.participant_team_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participant_team_id_seq OWNER TO postgres;

--
-- Name: participant_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.participant_team_id_seq OWNED BY public.participant_team.id;


--
-- Name: silk_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silk_profile (
    id integer NOT NULL,
    name character varying(300) NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    time_taken double precision,
    file_path character varying(300) NOT NULL,
    line_num integer,
    end_line_num integer,
    func_name character varying(300) NOT NULL,
    exception_raised boolean NOT NULL,
    dynamic boolean NOT NULL,
    request_id character varying(36)
);


ALTER TABLE public.silk_profile OWNER TO postgres;

--
-- Name: silk_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.silk_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.silk_profile_id_seq OWNER TO postgres;

--
-- Name: silk_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.silk_profile_id_seq OWNED BY public.silk_profile.id;


--
-- Name: silk_profile_queries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silk_profile_queries (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    sqlquery_id integer NOT NULL
);


ALTER TABLE public.silk_profile_queries OWNER TO postgres;

--
-- Name: silk_profile_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.silk_profile_queries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.silk_profile_queries_id_seq OWNER TO postgres;

--
-- Name: silk_profile_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.silk_profile_queries_id_seq OWNED BY public.silk_profile_queries.id;


--
-- Name: silk_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silk_request (
    id character varying(36) NOT NULL,
    path character varying(190) NOT NULL,
    query_params text NOT NULL,
    raw_body text NOT NULL,
    body text NOT NULL,
    method character varying(10) NOT NULL,
    start_time timestamp with time zone NOT NULL,
    view_name character varying(190),
    end_time timestamp with time zone,
    time_taken double precision,
    encoded_headers text NOT NULL,
    meta_time double precision,
    meta_num_queries integer,
    meta_time_spent_queries double precision,
    pyprofile text NOT NULL,
    num_sql_queries integer NOT NULL,
    prof_file character varying(100)
);


ALTER TABLE public.silk_request OWNER TO postgres;

--
-- Name: silk_response; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silk_response (
    id character varying(36) NOT NULL,
    status_code integer NOT NULL,
    raw_body text NOT NULL,
    body text NOT NULL,
    encoded_headers text NOT NULL,
    request_id character varying(36) NOT NULL
);


ALTER TABLE public.silk_response OWNER TO postgres;

--
-- Name: silk_sqlquery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.silk_sqlquery (
    id integer NOT NULL,
    query text NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    time_taken double precision,
    traceback text NOT NULL,
    request_id character varying(36)
);


ALTER TABLE public.silk_sqlquery OWNER TO postgres;

--
-- Name: silk_sqlquery_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.silk_sqlquery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.silk_sqlquery_id_seq OWNER TO postgres;

--
-- Name: silk_sqlquery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.silk_sqlquery_id_seq OWNED BY public.silk_sqlquery.id;


--
-- Name: starred_challenge; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.starred_challenge (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    challenge_id integer NOT NULL,
    user_id integer NOT NULL,
    is_starred boolean NOT NULL
);


ALTER TABLE public.starred_challenge OWNER TO postgres;

--
-- Name: starred_challenge_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.starred_challenge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.starred_challenge_id_seq OWNER TO postgres;

--
-- Name: starred_challenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.starred_challenge_id_seq OWNED BY public.starred_challenge.id;


--
-- Name: submission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.submission (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    status character varying(30) NOT NULL,
    is_public boolean NOT NULL,
    submission_number integer NOT NULL,
    download_count integer NOT NULL,
    submitted_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    when_made_public timestamp with time zone,
    input_file character varying(100) NOT NULL,
    stdout_file character varying(100),
    stderr_file character varying(100),
    challenge_phase_id integer NOT NULL,
    created_by_id integer NOT NULL,
    participant_team_id integer NOT NULL,
    execution_time_limit integer NOT NULL,
    output text,
    method_name character varying(1000) NOT NULL,
    method_description text NOT NULL,
    project_url character varying(1000) NOT NULL,
    publication_url character varying(1000) NOT NULL,
    submission_metadata_file character varying(100),
    submission_result_file character varying(100),
    is_flagged boolean NOT NULL,
    is_baseline boolean NOT NULL,
    job_name text[],
    CONSTRAINT submission_execution_time_limit_check CHECK ((execution_time_limit >= 0)),
    CONSTRAINT submission_submission_number_check CHECK ((submission_number >= 0))
);


ALTER TABLE public.submission OWNER TO postgres;

--
-- Name: submission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.submission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.submission_id_seq OWNER TO postgres;

--
-- Name: submission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.submission_id_seq OWNED BY public.submission.id;


--
-- Name: subscribers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscribers (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    email character varying(70) NOT NULL
);


ALTER TABLE public.subscribers OWNER TO postgres;

--
-- Name: subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subscribers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscribers_id_seq OWNER TO postgres;

--
-- Name: subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subscribers_id_seq OWNED BY public.subscribers.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(70),
    headshot character varying(100),
    visible boolean NOT NULL,
    github_url character varying(200),
    linkedin_url character varying(200),
    personal_website character varying(200),
    team_type character varying(50) NOT NULL,
    background_image character varying(100),
    description text,
    "position" integer NOT NULL,
    CONSTRAINT teams_position_check CHECK (("position" >= 0))
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO postgres;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: user_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_profile (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    contact_number character varying(10),
    affiliation character varying(512) NOT NULL,
    receive_participated_challenge_updates boolean NOT NULL,
    recieve_newsletter boolean NOT NULL,
    user_id integer NOT NULL,
    github_url character varying(200),
    google_scholar_url character varying(200),
    linkedin_url character varying(200)
);


ALTER TABLE public.user_profile OWNER TO postgres;

--
-- Name: user_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_profile_id_seq OWNER TO postgres;

--
-- Name: user_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_profile_id_seq OWNED BY public.user_profile.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: accounts_userstatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_userstatus ALTER COLUMN id SET DEFAULT nextval('public.accounts_userstatus_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: challenge id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge ALTER COLUMN id SET DEFAULT nextval('public.challenge_id_seq'::regclass);


--
-- Name: challenge_evaluation_cluster id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_evaluation_cluster ALTER COLUMN id SET DEFAULT nextval('public.challenge_evaluation_cluster_id_seq'::regclass);


--
-- Name: challenge_host id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host ALTER COLUMN id SET DEFAULT nextval('public.challenge_host_id_seq'::regclass);


--
-- Name: challenge_host_teams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host_teams ALTER COLUMN id SET DEFAULT nextval('public.challenge_host_teams_id_seq'::regclass);


--
-- Name: challenge_participant_teams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_participant_teams ALTER COLUMN id SET DEFAULT nextval('public.challenge_participant_teams_id_seq'::regclass);


--
-- Name: challenge_phase id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase ALTER COLUMN id SET DEFAULT nextval('public.challenge_test_env_id_seq'::regclass);


--
-- Name: challenge_phase_split id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase_split ALTER COLUMN id SET DEFAULT nextval('public.challenge_phase_split_id_seq'::regclass);


--
-- Name: challenge_zip_configuration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_zip_configuration ALTER COLUMN id SET DEFAULT nextval('public.challenge_zip_configuration_id_seq'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: dataset_split id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dataset_split ALTER COLUMN id SET DEFAULT nextval('public.dataset_split_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_ses_sesstat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_ses_sesstat ALTER COLUMN id SET DEFAULT nextval('public.django_ses_sesstat_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: invite_user_to_challenge id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_user_to_challenge ALTER COLUMN id SET DEFAULT nextval('public.invite_user_to_challenge_id_seq'::regclass);


--
-- Name: leaderboard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard ALTER COLUMN id SET DEFAULT nextval('public.leaderboard_id_seq'::regclass);


--
-- Name: leaderboard_data id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_data ALTER COLUMN id SET DEFAULT nextval('public.leaderboard_data_id_seq'::regclass);


--
-- Name: participant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant ALTER COLUMN id SET DEFAULT nextval('public.participant_id_seq'::regclass);


--
-- Name: participant_team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant_team ALTER COLUMN id SET DEFAULT nextval('public.participant_team_id_seq'::regclass);


--
-- Name: silk_profile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile ALTER COLUMN id SET DEFAULT nextval('public.silk_profile_id_seq'::regclass);


--
-- Name: silk_profile_queries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile_queries ALTER COLUMN id SET DEFAULT nextval('public.silk_profile_queries_id_seq'::regclass);


--
-- Name: silk_sqlquery id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_sqlquery ALTER COLUMN id SET DEFAULT nextval('public.silk_sqlquery_id_seq'::regclass);


--
-- Name: starred_challenge id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starred_challenge ALTER COLUMN id SET DEFAULT nextval('public.starred_challenge_id_seq'::regclass);


--
-- Name: submission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission ALTER COLUMN id SET DEFAULT nextval('public.submission_id_seq'::regclass);


--
-- Name: subscribers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscribers ALTER COLUMN id SET DEFAULT nextval('public.subscribers_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: user_profile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profile ALTER COLUMN id SET DEFAULT nextval('public.user_profile_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	admin@example.com	t	t	1
2	host@example.com	t	t	2
3	participant@example.com	t	t	3
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: accounts_userstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_userstatus (id, created_at, modified_at, name, status) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add user status	8	add_userstatus
23	Can change user status	8	change_userstatus
24	Can delete user status	8	delete_userstatus
25	Can add profile	9	add_profile
26	Can change profile	9	change_profile
27	Can delete profile	9	delete_profile
28	Can add challenge	10	add_challenge
29	Can change challenge	10	change_challenge
30	Can delete challenge	10	delete_challenge
31	Can add challenge phase	11	add_challengephase
32	Can change challenge phase	11	change_challengephase
33	Can delete challenge phase	11	delete_challengephase
34	Can add dataset split	12	add_datasetsplit
35	Can change dataset split	12	change_datasetsplit
36	Can delete dataset split	12	delete_datasetsplit
37	Can add leaderboard	13	add_leaderboard
38	Can change leaderboard	13	change_leaderboard
39	Can delete leaderboard	13	delete_leaderboard
40	Can add challenge phase split	14	add_challengephasesplit
41	Can change challenge phase split	14	change_challengephasesplit
42	Can delete challenge phase split	14	delete_challengephasesplit
43	Can add leaderboard data	15	add_leaderboarddata
44	Can change leaderboard data	15	change_leaderboarddata
45	Can delete leaderboard data	15	delete_leaderboarddata
46	Can add challenge configuration	16	add_challengeconfiguration
47	Can change challenge configuration	16	change_challengeconfiguration
48	Can delete challenge configuration	16	delete_challengeconfiguration
49	Can add star challenge	17	add_starchallenge
50	Can change star challenge	17	change_starchallenge
51	Can delete star challenge	17	delete_starchallenge
52	Can add user invitation	18	add_userinvitation
53	Can change user invitation	18	change_userinvitation
54	Can delete user invitation	18	delete_userinvitation
55	Can add challenge evaluation cluster	19	add_challengeevaluationcluster
56	Can change challenge evaluation cluster	19	change_challengeevaluationcluster
57	Can delete challenge evaluation cluster	19	delete_challengeevaluationcluster
58	Can add challenge host	20	add_challengehost
59	Can change challenge host	20	change_challengehost
60	Can delete challenge host	20	delete_challengehost
61	Can add challenge host team	21	add_challengehostteam
62	Can change challenge host team	21	change_challengehostteam
63	Can delete challenge host team	21	delete_challengehostteam
64	Can add submission	22	add_submission
65	Can change submission	22	change_submission
66	Can delete submission	22	delete_submission
67	Can add participant	23	add_participant
68	Can change participant	23	change_participant
69	Can delete participant	23	delete_participant
70	Can add participant team	24	add_participantteam
71	Can change participant team	24	change_participantteam
72	Can delete participant team	24	delete_participantteam
73	Can add contact	25	add_contact
74	Can change contact	25	change_contact
75	Can delete contact	25	delete_contact
76	Can add team	26	add_team
77	Can change team	26	change_team
78	Can delete team	26	delete_team
79	Can add subscribers	27	add_subscribers
80	Can change subscribers	27	change_subscribers
81	Can delete subscribers	27	delete_subscribers
82	Can add email address	28	add_emailaddress
83	Can change email address	28	change_emailaddress
84	Can delete email address	28	delete_emailaddress
85	Can add email confirmation	29	add_emailconfirmation
86	Can change email confirmation	29	change_emailconfirmation
87	Can delete email confirmation	29	delete_emailconfirmation
88	Can add cors model	30	add_corsmodel
89	Can change cors model	30	change_corsmodel
90	Can delete cors model	30	delete_corsmodel
91	Can add SES Stat	31	add_sesstat
92	Can change SES Stat	31	change_sesstat
93	Can delete SES Stat	31	delete_sesstat
94	Can add Token	32	add_token
95	Can change Token	32	change_token
96	Can delete Token	32	delete_token
97	Can add expiring token	32	add_expiringtoken
98	Can change expiring token	32	change_expiringtoken
99	Can delete expiring token	32	delete_expiringtoken
100	Can add profile	34	add_profile
101	Can change profile	34	change_profile
102	Can delete profile	34	delete_profile
103	Can add request	35	add_request
104	Can change request	35	change_request
105	Can delete request	35	delete_request
106	Can add response	36	add_response
107	Can change response	36	change_response
108	Can delete response	36	delete_response
109	Can add sql query	37	add_sqlquery
110	Can change sql query	37	change_sqlquery
111	Can delete sql query	37	delete_sqlquery
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$36000$bjhCTyMkyYj7$oxRvyYhx6GLVr3UrZmEj5AnfvHWRw36Yf5AJYlXt99M=	\N	t	admin			admin@example.com	t	t	2020-06-05 17:50:37.977528+00
2	pbkdf2_sha256$36000$1xV2OYFtVirp$jjKwE/xlfRNPJ3v6NDk2top1DywuOdRTaJDXFtYr9nM=	\N	f	host			host@example.com	f	t	2020-06-05 17:50:38.037913+00
3	pbkdf2_sha256$36000$J8QjAvRiwLe5$qLbaVhaxx4YvXqgfwiBF3bCp6KbD7AO6eUttKrv9bVc=	\N	f	participant			participant@example.com	f	t	2020-06-05 17:50:38.124643+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: challenge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge (id, created_at, modified_at, title, description, terms_and_conditions, submission_guidelines, evaluation_details, image, start_date, end_date, published, enable_forum, anonymous_leaderboard, creator_id, is_disabled, evaluation_script, approved_by_admin, short_description, featured, allowed_email_domains, blocked_email_domains, forum_url, remote_evaluation, queue, is_docker_based, slug, max_docker_image_size, leaderboard_description, max_concurrent_submission_evaluation, aws_access_key_id, aws_account_id, aws_region, aws_secret_access_key, use_host_credentials, cli_version, is_registration_open, banned_email_ids, task_def_arn, workers, slack_webhook_url) FROM stdin;
1	2020-06-05 17:50:38.11493+00	2020-06-05 17:50:38.114967+00	Joshua Challenge	Eaque doloremque dolorum quod porro aspernatur tempora nulla. Soluta dolor quis dicta odit dignissimos beatae. Maiores magni quas repellat magni numquam.	Iusto consequatur vitae repellendus itaque. Deleniti illo occaecati error quo. Rerum reiciendis ex nam veritatis.	Sapiente aperiam inventore aperiam impedit. Esse corporis aspernatur dignissimos quisquam optio eligendi incidunt. Est atque libero soluta. Consequatur velit magnam ratione adipisci.	Fugiat unde distinctio id asperiores. Rerum voluptates ipsa doloremque consequatur totam ad labore dolorum. Voluptates nulla ab quas quo. Voluptatem tempore a asperiores maiores sequi praesentium. Eum vitae quasi corrupti itaque optio.		2020-02-26 17:50:38.110147+00	2021-10-18 17:50:38.110167+00	t	t	f	1	f	evaluation_scripts/b2e8d7ce-74e2-4a20-9364-94f9527fb457.zip	t	Aperiam voluptatum similique illum a occaecati placeat accusamus atque. Vel explicabo corrupti soluta repudiandae assumenda eveniet velit. Voluptas rerum quibusdam dignissimos voluptatum suscipit ducimus.	f	{}	{}	\N	f	PxlwQNHNrqJvVcdNVisWHPMxUcszHCTHOmvpivdibuqsXojOWLPBGVbvrHbkMSLxgkYmTdCRkFc	f	joshua-challenge-None	42949672960	Assumenda voluptates explicabo voluptatibus earum. Nobis distinctio dolores architecto tenetur quae eum aperiam. Sint autem pariatur minima.	100000			us-east-1		f	\N	t	{}		\N	\N
\.


--
-- Data for Name: challenge_evaluation_cluster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_evaluation_cluster (id, created_at, modified_at, name, cluster_yaml, kube_config, challenge_id) FROM stdin;
\.


--
-- Data for Name: challenge_host; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_host (id, created_at, modified_at, status, permissions, team_name_id, user_id) FROM stdin;
1	2020-06-05 17:50:38.103181+00	2020-06-05 17:50:38.103216+00	Self	Admin	1	2
\.


--
-- Data for Name: challenge_host_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_host_teams (id, created_at, modified_at, team_name, created_by_id, team_url) FROM stdin;
1	2020-06-05 17:50:38.096519+00	2020-06-05 17:50:38.096587+00	South Kirk Host Team	2	
\.


--
-- Data for Name: challenge_participant_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_participant_teams (id, challenge_id, participantteam_id) FROM stdin;
\.


--
-- Data for Name: challenge_phase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_phase (id, created_at, modified_at, name, description, leaderboard_public, start_date, end_date, test_annotation, challenge_id, max_submissions, max_submissions_per_day, is_public, codename, is_submission_public, max_concurrent_submissions_allowed, max_submissions_per_month, allowed_email_ids, slug, environment_image, allowed_submission_file_types, is_restricted_to_select_one_submission) FROM stdin;
1	2020-06-05 17:50:38.22395+00	2020-06-05 17:50:38.223991+00	Eric Phase	Quia natus animi voluptate nihil maiores possimus. Corrupti delectus fuga maxime voluptates sint. Doloribus odio reiciendis modi consequatur necessitatibus numquam delectus. Beatae possimus earum culpa quibusdam.	t	2020-02-26 17:50:38.110147+00	2021-10-18 17:50:38.110167+00	test_annotations/8c8fc5ba-2a69-4063-b425-0d33368b857b.txt	1	100000	100000	t	phase1	t	3	100000	{}	eric-phase-2020	\N	.json, .zip, .txt, .tsv, .gz, .csv, .h5, .npy	f
2	2020-06-05 17:50:38.23437+00	2020-06-05 17:50:38.234407+00	Marcus Phase	Ad incidunt qui inventore eveniet eius molestias ipsa culpa. Provident minus similique ad incidunt occaecati.	t	2020-02-26 17:50:38.110147+00	2021-10-18 17:50:38.110167+00	test_annotations/bf17209c-63d0-4645-8522-8dfd64a536da.txt	1	100000	100000	t	phase2	t	3	100000	{}	marcus-phase-2020	\N	.json, .zip, .txt, .tsv, .gz, .csv, .h5, .npy	f
\.


--
-- Data for Name: challenge_phase_split; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_phase_split (id, created_at, modified_at, visibility, challenge_phase_id, dataset_split_id, leaderboard_id, is_leaderboard_order_descending, leaderboard_decimal_precision, show_leaderboard_by_latest_submission) FROM stdin;
1	2020-06-05 17:50:38.311751+00	2020-06-05 17:50:38.311783+00	3	1	1	1	t	2	f
2	2020-06-05 17:50:38.328365+00	2020-06-05 17:50:38.328406+00	3	1	2	1	t	2	f
3	2020-06-05 17:50:38.387622+00	2020-06-05 17:50:38.387747+00	3	2	1	1	t	2	f
4	2020-06-05 17:50:38.401275+00	2020-06-05 17:50:38.401407+00	3	2	2	1	t	2	f
\.


--
-- Data for Name: challenge_zip_configuration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challenge_zip_configuration (id, created_at, modified_at, zip_configuration, is_created, stdout_file, stderr_file, challenge_id, user_id) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact (id, created_at, modified_at, name, email, message, status) FROM stdin;
\.


--
-- Data for Name: dataset_split; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dataset_split (id, created_at, modified_at, name, codename) FROM stdin;
1	2020-06-05 17:50:38.239452+00	2020-06-05 17:50:38.23949+00	Split 1	split1
2	2020-06-05 17:50:38.244966+00	2020-06-05 17:50:38.245068+00	Split 2	split2
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	sites	site
8	accounts	userstatus
9	accounts	profile
10	challenges	challenge
11	challenges	challengephase
12	challenges	datasetsplit
13	challenges	leaderboard
14	challenges	challengephasesplit
15	challenges	leaderboarddata
16	challenges	challengeconfiguration
17	challenges	starchallenge
18	challenges	userinvitation
19	challenges	challengeevaluationcluster
20	hosts	challengehost
21	hosts	challengehostteam
22	jobs	submission
23	participants	participant
24	participants	participantteam
25	web	contact
26	web	team
27	web	subscribers
28	account	emailaddress
29	account	emailconfirmation
30	corsheaders	corsmodel
31	django_ses	sesstat
32	authtoken	token
33	rest_framework_expiring_authtoken	expiringtoken
34	silk	profile
35	silk	request
36	silk	response
37	silk	sqlquery
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2020-06-05 17:50:17.802978+00
2	auth	0001_initial	2020-06-05 17:50:18.020567+00
3	account	0001_initial	2020-06-05 17:50:18.515603+00
4	account	0002_email_max_length	2020-06-05 17:50:18.5638+00
5	accounts	0001_initial	2020-06-05 17:50:18.701763+00
6	accounts	0002_profile	2020-06-05 17:50:18.797795+00
7	accounts	remove_affiliation_model	2020-06-05 17:50:18.898707+00
8	accounts	0001_add_url_fields_in_profile_model	2020-06-05 17:50:18.960823+00
9	admin	0001_initial	2020-06-05 17:50:19.031463+00
10	admin	0002_logentry_remove_auto_add	2020-06-05 17:50:19.080307+00
11	contenttypes	0002_remove_content_type_name	2020-06-05 17:50:19.175265+00
12	auth	0002_alter_permission_name_max_length	2020-06-05 17:50:19.189394+00
13	auth	0003_alter_user_email_max_length	2020-06-05 17:50:19.228192+00
14	auth	0004_alter_user_username_opts	2020-06-05 17:50:19.280168+00
15	auth	0005_alter_user_last_login_null	2020-06-05 17:50:19.331913+00
16	auth	0006_require_contenttypes_0002	2020-06-05 17:50:19.338537+00
17	auth	0007_alter_validators_add_error_messages	2020-06-05 17:50:19.379303+00
18	auth	0008_alter_user_username_max_length	2020-06-05 17:50:19.43568+00
19	authtoken	0001_initial	2020-06-05 17:50:19.509935+00
20	authtoken	0002_auto_20160226_1747	2020-06-05 17:50:19.628975+00
21	hosts	0001_initial	2020-06-05 17:50:19.726408+00
22	hosts	0002_added_unique_attribute_in_team_name	2020-06-05 17:50:19.762616+00
23	hosts	0003_challengehostteam_team_url	2020-06-05 17:50:19.826328+00
24	hosts	Add_blank_in_host_team_URL	2020-06-05 17:50:19.881227+00
25	challenges	0001_initial	2020-06-05 17:50:19.976827+00
26	participants	0001_initial	2020-06-05 17:50:20.104522+00
27	participants	0002_participantteam_participantteammember	2020-06-05 17:50:20.222343+00
28	participants	0003_remove_participant_challenge	2020-06-05 17:50:20.276695+00
29	participants	0004_add_created_by_participant_team	2020-06-05 17:50:20.331574+00
30	participants	0005_remove_participantteam_challenge	2020-06-05 17:50:20.392489+00
31	participants	0006_alter_status_participant_choices	2020-06-05 17:50:20.461089+00
32	participants	0007_add_team_participant	2020-06-05 17:50:20.557894+00
33	challenges	0002_challenge_participant_teams	2020-06-05 17:50:20.623759+00
34	challenges	0003_auto_20161203_2258	2020-06-05 17:50:20.699582+00
35	challenges	0004_challenge_is_disabled	2020-06-05 17:50:20.745398+00
36	challenges	0005_changed_phase_model	2020-06-05 17:50:20.890363+00
37	challenges	0006_changed_path_to_upload	2020-06-05 17:50:20.920525+00
38	challenges	0007_rename_test_environment	2020-06-05 17:50:20.997225+00
39	jobs	0001_squashed_0005_upload_unique_random_filename	2020-06-05 17:50:21.072252+00
40	challenges	0008_max_submissions	2020-06-05 17:50:21.172614+00
41	challenges	0009_challengephase_is_public	2020-06-05 17:50:21.241009+00
42	challenges	0010_update_upload_folder_names	2020-06-05 17:50:21.28911+00
43	challenges	0011_approved_by_admin_field_added	2020-06-05 17:50:21.354881+00
44	challenges	0012_added_code_name_field	2020-06-05 17:50:21.418776+00
45	challenges	0013_added_code_name_field	2020-06-05 17:50:21.448304+00
46	challenges	0014_changed_code_name_field	2020-06-05 17:50:21.506565+00
47	challenges	0015_added_dataset_split	2020-06-05 17:50:21.530659+00
48	challenges	0016_added_dataset_split_as_m2m_field	2020-06-05 17:50:21.622533+00
49	challenges	0017_added_leaderboard_table	2020-06-05 17:50:21.655011+00
50	challenges	0018_added_challenge_phase_split_table	2020-06-05 17:50:21.753134+00
51	challenges	0019_added_leaderboard_data_table	2020-06-05 17:50:21.836125+00
52	challenges	0020_alter_challenge_phase_split	2020-06-05 17:50:21.90939+00
53	challenges	0021_remove_challengephase_dataset_split	2020-06-05 17:50:21.960963+00
54	challenges	0022_challengephase_dataset_split	2020-06-05 17:50:22.010551+00
55	challenges	0023_upload_unique_random_filename	2020-06-05 17:50:22.494115+00
56	challenges	0024_added_short_description_field	2020-06-05 17:50:22.533027+00
57	challenges	0025_added_is_submission_pubblic_field	2020-06-05 17:50:22.613062+00
58	challenges	0026_adds_default_field_in_test_annotation	2020-06-05 17:50:22.662354+00
59	challenges	0027_adds_unique_to_codename_dataset_split	2020-06-05 17:50:22.717517+00
60	challenges	0028_zip_configuration_models_for_challenge_creation	2020-06-05 17:50:22.840613+00
61	challenges	0029_add_challenge_star	2020-06-05 17:50:22.965884+00
62	challenges	0030_add_boolean_field_in_star_model	2020-06-05 17:50:23.098913+00
63	challenges	0031_add_db_index_to_challenge_related_models	2020-06-05 17:50:23.499433+00
64	challenges	0032_adds_featured_field_in_challenge	2020-06-05 17:50:23.59557+00
65	challenges	0033_delete_unique_constraint_from_datasetsplit_table	2020-06-05 17:50:23.644243+00
66	challenges	0034_add_allow_block_domain_fields	2020-06-05 17:50:23.829878+00
67	challenges	0035_add_max_concurrent_submissions_allowed_field	2020-06-05 17:50:23.927588+00
68	challenges	0036_Add_unique_random_name_to_challenge_logo	2020-06-05 17:50:23.966461+00
69	challenges	0037_add_field_to_store_forum_url	2020-06-05 17:50:24.028925+00
70	challenges	0038_challenge_remote_evaluation	2020-06-05 17:50:24.151335+00
71	challenges	0039_add_sqs_broker_url_for_challenge_based_worker	2020-06-05 17:50:24.307933+00
72	challenges	0040_change_broker_url_name_to_queue	2020-06-05 17:50:24.365341+00
73	challenges	0041_add_challenge_phase_max_submissions_per_month	2020-06-05 17:50:24.476049+00
74	challenges	0042_add_slug_field_and_flag_for_docker_based_challenges	2020-06-05 17:50:24.840465+00
75	challenges	0043_add_max_docker_image_size_for_challenge	2020-06-05 17:50:25.111933+00
76	challenges	0044_add_field_to_allow_email_ids_in_challenge_phase	2020-06-05 17:50:25.301239+00
77	challenges	0045_Add_leaderboard_description_field_in_challenge	2020-06-05 17:50:25.376313+00
78	challenges	0046_add_max_concurrent_submission_evaluation_in_challenge	2020-06-05 17:50:25.733501+00
79	challenges	0047_add_model_to_invite_user_in_challenge	2020-06-05 17:50:25.932687+00
80	challenges	0048_add_fields_to_store_host_aws_keys	2020-06-05 17:50:27.130301+00
81	challenges	0049_add_slug_field_in_challenge_phase	2020-06-05 17:50:27.186998+00
82	challenges	0050_remove_charfield_from_challenge_slug	2020-06-05 17:50:27.256142+00
83	challenges	0051_add_field_to_store_evalai_cli_version	2020-06-05 17:50:27.306825+00
84	challenges	0052_add_error_bar	2020-06-05 17:50:27.355671+00
85	challenges	0053_added_is_registration_open_field	2020-06-05 17:50:27.519029+00
86	challenges	0054_add_banned_email_ids_field	2020-06-05 17:50:27.687762+00
87	challenges	0055_add_is_leaderboard_order_descending_in_phase_split_model	2020-06-05 17:50:27.776656+00
88	challenges	0056_add_leaderboard_decimal_precision_field_in_phase_split_model	2020-06-05 17:50:27.863012+00
89	challenges	0057_add_task_def_arn_and_workers_field_to_challenge_model	2020-06-05 17:50:28.052685+00
90	challenges	0058_add_show_leaderboard_by_latest_submission_field_in_challenge_phase_split_model	2020-06-05 17:50:28.104226+00
91	challenges	0058_adding_environment_url_for_rl_challenges	2020-06-05 17:50:28.156309+00
92	challenges	0059_add_blank_in_phase_environment_url	2020-06-05 17:50:28.194548+00
93	challenges	0060_modify_environment_image_field_in_challenge_phase_model	2020-06-05 17:50:28.296988+00
94	challenges	0061_add_models_to_store_kubernetes_cluster_details	2020-06-05 17:50:28.831418+00
95	challenges	0062_add_allowed_submission_file_types_field_in_phase_model	2020-06-05 17:50:28.991221+00
96	challenges	0063_add_slack_webhook_url_field_in_challenge_model	2020-06-05 17:50:29.060246+00
97	challenges	0064_add_is_restricted_to_select_one_submission_field_in_phase_model	2020-06-05 17:50:29.227087+00
98	django_ses	0001_initial	2020-06-05 17:50:29.258908+00
99	jobs	0002_path_fix_for_submission_files	2020-06-05 17:50:29.374264+00
100	jobs	0003_added_method_name_field	2020-06-05 17:50:29.416545+00
101	jobs	0004_added_method_desc_aand_urls_to_submission_model	2020-06-05 17:50:29.513966+00
102	jobs	0005_added_new_fields_to_submission_model	2020-06-05 17:50:29.580629+00
103	jobs	0006_add_indexing_to_some_attributes	2020-06-05 17:50:29.878611+00
104	jobs	0007_add_is_flagged_field	2020-06-05 17:50:30.032558+00
105	jobs	0008_remove_indexing_submission	2020-06-05 17:50:30.17724+00
106	jobs	0009_auto_20180629_0334	2020-06-05 17:50:30.293248+00
107	jobs	0010_Add_blank_in_submission_metadata	2020-06-05 17:50:30.380539+00
108	jobs	0011_Change_submission_visibility_default_to_public	2020-06-05 17:50:30.410007+00
109	jobs	0012_add_baseline_submission	2020-06-05 17:50:30.525123+00
110	jobs	0013_add_job_id_field_in_submission_model	2020-06-05 17:50:30.660972+00
111	jobs	0014_rename_job_id_field_in_submission_model_to_job_name	2020-06-05 17:50:30.730252+00
112	jobs	0015_add_archived_as_a_submission_status	2020-06-05 17:50:30.765243+00
113	participants	0008_added_unique_in_team_name	2020-06-05 17:50:30.823516+00
114	participants	0009_participantteam_team_url	2020-06-05 17:50:30.90352+00
115	participants	0010_Add_blank_in_team_URL	2020-06-05 17:50:31.105172+00
116	participants	0011_add_docker_repository_uri_for_each_participant_team	2020-06-05 17:50:31.170878+00
117	participants	0012_remove_docker_repository_uri_from_team	2020-06-05 17:50:31.220727+00
118	rest_framework_expiring_authtoken	0001_initial	2020-06-05 17:50:31.232586+00
119	sessions	0001_initial	2020-06-05 17:50:31.272365+00
120	silk	0001_initial	2020-06-05 17:50:31.540387+00
121	silk	0002_auto_update_uuid4_id_field	2020-06-05 17:50:31.596446+00
122	silk	0003_request_prof_file	2020-06-05 17:50:31.6172+00
123	silk	0004_request_prof_file_storage	2020-06-05 17:50:31.651176+00
124	sites	0001_initial	2020-06-05 17:50:31.676176+00
125	sites	0002_alter_domain_unique	2020-06-05 17:50:31.711053+00
126	web	0001_initial	2020-06-05 17:50:31.745149+00
127	web	0002_added_team_model	2020-06-05 17:50:31.792903+00
128	web	0003_added_description_and_background_image_to_team_model	2020-06-05 17:50:31.828602+00
129	web	0004_change_team_model_field_type	2020-06-05 17:50:31.892242+00
130	web	0005_modified_default_attribute_of_visible_field_to_false	2020-06-05 17:50:31.907317+00
131	web	0006_add_status_field_in_contact_model	2020-06-05 17:50:31.945276+00
132	web	0007_add_position_in_team_model	2020-06-05 17:50:31.986426+00
133	web	0008_modify_description_field_to_be_blank	2020-06-05 17:50:32.006405+00
134	web	0009_added_subscribers_model	2020-06-05 17:50:32.035513+00
135	web	0010_add_verbose_name_plural_for_subscribers_model	2020-06-05 17:50:32.059783+00
\.


--
-- Data for Name: django_ses_sesstat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_ses_sesstat (id, date, delivery_attempts, bounces, complaints, rejects) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: invite_user_to_challenge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite_user_to_challenge (id, created_at, modified_at, email, invitation_key, status, challenge_id, invited_by_id, user_id) FROM stdin;
\.


--
-- Data for Name: leaderboard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaderboard (id, created_at, modified_at, schema) FROM stdin;
1	2020-06-05 17:50:38.218338+00	2020-06-05 17:50:38.218377+00	{"labels": ["score"], "default_order_by": "score"}
\.


--
-- Data for Name: leaderboard_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaderboard_data (id, created_at, modified_at, result, challenge_phase_split_id, leaderboard_id, submission_id, error) FROM stdin;
1	2020-06-05 17:50:38.320799+00	2020-06-05 17:50:38.320832+00	{"score": 21}	1	1	1	\N
2	2020-06-05 17:50:38.335609+00	2020-06-05 17:50:38.335643+00	{"score": 75}	2	1	1	\N
3	2020-06-05 17:50:38.394809+00	2020-06-05 17:50:38.394845+00	{"score": 71}	3	1	2	\N
4	2020-06-05 17:50:38.407677+00	2020-06-05 17:50:38.407815+00	{"score": 54}	4	1	2	\N
\.


--
-- Data for Name: participant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participant (id, created_at, modified_at, status, user_id, team_id) FROM stdin;
1	2020-06-05 17:50:38.208074+00	2020-06-05 17:50:38.208193+00	Self	3	1
\.


--
-- Data for Name: participant_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participant_team (id, created_at, modified_at, team_name, created_by_id, team_url) FROM stdin;
1	2020-06-05 17:50:38.200145+00	2020-06-05 17:50:38.200292+00	Port James Participant Team	3	
\.


--
-- Data for Name: silk_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silk_profile (id, name, start_time, end_time, time_taken, file_path, line_num, end_line_num, func_name, exception_raised, dynamic, request_id) FROM stdin;
\.


--
-- Data for Name: silk_profile_queries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silk_profile_queries (id, profile_id, sqlquery_id) FROM stdin;
\.


--
-- Data for Name: silk_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silk_request (id, path, query_params, raw_body, body, method, start_time, view_name, end_time, time_taken, encoded_headers, meta_time, meta_num_queries, meta_time_spent_queries, pyprofile, num_sql_queries, prof_file) FROM stdin;
ad73d218-5056-43ab-afb1-87c6b2dca0a0	/media/evaluation_scripts/b2e8d7ce-74e2-4a20-9364-94f9527fb457.zip				GET	2020-06-05 17:50:51.167286+00	django.views.static.serve	2020-06-05 17:50:51.202188+00	34.902000000000001	{"CONTENT-LENGTH": "", "CONTENT-TYPE": "text/plain", "HOST": "django:8000", "USER-AGENT": "python-requests/2.23.0", "ACCEPT-ENCODING": "gzip, deflate", "ACCEPT": "*/*", "CONNECTION": "keep-alive"}	\N	\N	\N	         760 function calls (728 primitive calls) in 0.004 seconds\n\n   Ordered by: cumulative time\n\n   ncalls  tottime  percall  cumtime  percall filename:lineno(function)\n        1    0.000    0.000    0.004    0.004 /usr/local/lib/python3.6/site-packages/django/core/handlers/exception.py:38(inner)\n        1    0.000    0.000    0.004    0.004 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:157(_get_response)\n        1    0.000    0.000    0.003    0.003 /usr/local/lib/python3.6/site-packages/django/views/static.py:23(serve)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/mimetypes.py:271(guess_type)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/mimetypes.py:97(guess_type)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/urllib/parse.py:932(splittype)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/re.py:231(compile)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/re.py:286(_compile)\n        1    0.000    0.000    0.002    0.002 /usr/local/lib/python3.6/sre_compile.py:557(compile)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/sre_compile.py:542(_code)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/sre_parse.py:844(parse)\n      5/1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/sre_compile.py:64(_compile)\n     17/1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:358(resolve)\n      3/1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/sre_parse.py:407(_parse_sub)\n      3/1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/sre_parse.py:470(_parse)\n       19    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/enum.py:801(__and__)\n       48    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/enum.py:265(__call__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:131(process_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:49(inner)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:371(__init__)\n       48    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/enum.py:515(__new__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:54(safe_join)\n        1    0.000    0.000    0.000    0.000 {built-in method io.open}\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:388(_simple)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:150(__setitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:482(_compile_info)\n        8    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:191(resolve)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:106(_process_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/http.py:133(http_date)\n      9/5    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:173(getwidth)\n        5    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/enum.py:795(__or__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:41(__init__)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:331(normpath)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:223(_compile_charset)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:138(formatdate)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:828(fix_flags)\n       79    0.000    0.000    0.000    0.000 {built-in method builtins.isinstance}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:151(__enter__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:96(closegroup)\n        6    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:114(_convert_to_charset)\n        3    0.000    0.000    0.000    0.000 {built-in method posix.stat}\n       25    0.000    0.000    0.000    0.000 {method 'search' of '_sre.SRE_Pattern' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:250(_optimize_charset)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:39(isdir)\n       17    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:163(__getitem__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:369(abspath)\n       19    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/encoding.py:58(force_text)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:167(format_datetime)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:34(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:109(make_view_atomic)\n       14    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:232(__next)\n       10    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:253(get)\n       85    0.000    0.000    0.000    0.000 {method 'append' of 'list' objects}\n      9/8    0.000    0.000    0.000    0.000 {built-in method builtins.getattr}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/middleware.py:93(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:388(set_autocommit)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:388(streaming_content)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:225(all)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:121(splitext)\n       10    0.000    0.000    0.000    0.000 {built-in method builtins.hasattr}\n    42/40    0.000    0.000    0.000    0.000 {built-in method builtins.len}\n       12    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:248(match)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/debug_toolbar/middleware.py:82(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/conf.py:51(CORS_REPLACE_HTTPS_REFERER)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:411(_set_streaming_content)\n      2/1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:414(_get_literal_prefix)\n        1    0.000    0.000    0.000    0.000 {method 'timetuple' of 'datetime.datetime' objects}\n        8    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:285(tell)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:31(__enter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:75(join)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:27(_should_meta_profile)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/postgresql/base.py:234(_set_autocommit)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:204(__getitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:117(_splitext)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:210(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:14(get_connection)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:84(opengroup)\n       11    0.000    0.000    0.000    0.000 {built-in method builtins.min}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:129(_format_timetuple_and_zone)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:226(<listcomp>)\n        7    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:159(__len__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:441(_get_charset_prefix)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:16(exists)\n        5    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:111(__init__)\n        5    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:171(append)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/collector.py:140(stop_python_profiler)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1284(debug)\n        6    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:81(groups)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:223(__init__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:64(isabs)\n       19    0.000    0.000    0.000    0.000 {method 'get' of 'dict' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/views/static.py:113(was_modified_since)\n        1    0.000    0.000    0.000    0.000 {built-in method fromtimestamp}\n        5    0.000    0.000    0.000    0.000 {method 'find' of 'bytearray' objects}\n        6    0.000    0.000    0.000    0.000 {method 'encode' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1230(current_thread)\n       19    0.000    0.000    0.000    0.000 {built-in method builtins.issubclass}\n        1    0.000    0.000    0.000    0.000 {built-in method _sre.compile}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:23(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:392(_set_streaming_content)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1542(isEnabledFor)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:222(__iter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/conf/__init__.py:51(__getattr__)\n        3    0.000    0.000    0.000    0.000 {method 'split' of 'str' objects}\n       11    0.000    0.000    0.000    0.000 {method 'join' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {method 'match' of '_sre.SRE_Pattern' objects}\n        9    0.000    0.000    0.000    0.000 {method 'startswith' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:381(get_autocommit)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:52(normcase)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:41(_get_sep)\n       11    0.000    0.000    0.000    0.000 {built-in method posix.fspath}\n        4    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:57(__getitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:76(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/config.py:43(__getattr__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:63(<listcomp>)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_compile.py:539(isstring)\n        2    0.000    0.000    0.000    0.000 {method 'groupdict' of '_sre.SRE_Match' objects}\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:207(ensure_connection)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/urllib/parse.py:600(unquote)\n        2    0.000    0.000    0.000    0.000 {method 'update' of 'dict' objects}\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/singleton.py:9(__call__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1528(getEffectiveLevel)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/sre_parse.py:167(__setitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1092(ident)\n        3    0.000    0.000    0.000    0.000 {method 'lower' of 'str' objects}\n        2    0.000    0.000    0.000    0.000 {method 'rfind' of 'str' objects}\n        3    0.000    0.000    0.000    0.000 {built-in method builtins.iter}\n        3    0.000    0.000    0.000    0.000 {built-in method builtins.ord}\n        1    0.000    0.000    0.000    0.000 {built-in method _thread.get_ident}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:437(validate_no_atomic_block)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/http/cookies.py:504(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:148(_accept)\n        1    0.000    0.000    0.000    0.000 {method 'items' of 'dict' objects}\n        1    0.000    0.000    0.000    0.000 {method 'disable' of '_lsprof.Profiler' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:42(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:44(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:70(__exit__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:36(_recreate_cm)\n        1    0.000    0.000    0.000    0.000 {method 'extend' of 'list' objects}\n        1    0.000    0.000    0.000    0.000 {method 'lstrip' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {method 'endswith' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {method 'end' of '_sre.SRE_Match' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISDIR}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISREG}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:67(__enter__)\n\n\n	0	
545d1368-56a2-4c88-86e8-026c6b47ba34	/media/test_annotations/bf17209c-63d0-4645-8522-8dfd64a536da.txt				GET	2020-06-05 17:50:51.227723+00	django.views.static.serve	2020-06-05 17:50:51.239339+00	11.6159999999999997	{"CONTENT-LENGTH": "", "CONTENT-TYPE": "text/plain", "HOST": "django:8000", "USER-AGENT": "python-requests/2.23.0", "ACCEPT-ENCODING": "gzip, deflate", "ACCEPT": "*/*", "CONNECTION": "keep-alive"}	\N	\N	\N	         349 function calls (332 primitive calls) in 0.001 seconds\n\n   Ordered by: cumulative time\n\n   ncalls  tottime  percall  cumtime  percall filename:lineno(function)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/site-packages/django/core/handlers/exception.py:38(inner)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:157(_get_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/views/static.py:23(serve)\n     17/1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:358(resolve)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:131(process_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:49(inner)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:54(safe_join)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:371(__init__)\n        8    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:191(resolve)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:150(__setitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/http.py:133(http_date)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:138(formatdate)\n        3    0.000    0.000    0.000    0.000 {built-in method posix.stat}\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:331(normpath)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:39(isdir)\n       25    0.000    0.000    0.000    0.000 {method 'search' of '_sre.SRE_Pattern' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method io.open}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:106(_process_response)\n        6    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:114(_convert_to_charset)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:41(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/debug_toolbar/middleware.py:82(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/mimetypes.py:271(guess_type)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:167(format_datetime)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:151(__enter__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:369(abspath)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/mimetypes.py:97(guess_type)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:34(__init__)\n       19    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/encoding.py:58(force_text)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:109(make_view_atomic)\n      9/8    0.000    0.000    0.000    0.000 {built-in method builtins.getattr}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/middleware.py:93(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:225(all)\n        1    0.000    0.000    0.000    0.000 {method 'timetuple' of 'datetime.datetime' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/conf.py:51(CORS_REPLACE_HTTPS_REFERER)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:388(streaming_content)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:210(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:388(set_autocommit)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1230(current_thread)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:75(join)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:121(splitext)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:411(_set_streaming_content)\n       33    0.000    0.000    0.000    0.000 {built-in method builtins.isinstance}\n       10    0.000    0.000    0.000    0.000 {built-in method builtins.hasattr}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:31(__enter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:129(_format_timetuple_and_zone)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:226(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:117(_splitext)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:27(_should_meta_profile)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/postgresql/base.py:234(_set_autocommit)\n        1    0.000    0.000    0.000    0.000 {built-in method fromtimestamp}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:16(exists)\n       19    0.000    0.000    0.000    0.000 {method 'get' of 'dict' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:23(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/collector.py:140(stop_python_profiler)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:204(__getitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/urllib/parse.py:932(splittype)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:64(isabs)\n       32    0.000    0.000    0.000    0.000 {method 'append' of 'list' objects}\n        6    0.000    0.000    0.000    0.000 {method 'encode' of 'str' objects}\n       19    0.000    0.000    0.000    0.000 {built-in method builtins.issubclass}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/views/static.py:113(was_modified_since)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:381(get_autocommit)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:392(_set_streaming_content)\n        4    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:57(__getitem__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1284(debug)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1542(isEnabledFor)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:14(get_connection)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:222(__iter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/conf/__init__.py:51(__getattr__)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:41(_get_sep)\n        3    0.000    0.000    0.000    0.000 {method 'split' of 'str' objects}\n       11    0.000    0.000    0.000    0.000 {method 'join' of 'str' objects}\n        9    0.000    0.000    0.000    0.000 {method 'startswith' of 'str' objects}\n       11    0.000    0.000    0.000    0.000 {built-in method posix.fspath}\n        2    0.000    0.000    0.000    0.000 {method 'groupdict' of '_sre.SRE_Match' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/config.py:43(__getattr__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:63(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1092(ident)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:52(normcase)\n        2    0.000    0.000    0.000    0.000 {method 'update' of 'dict' objects}\n        3    0.000    0.000    0.000    0.000 {method 'lower' of 'str' objects}\n        2    0.000    0.000    0.000    0.000 {method 'rfind' of 'str' objects}\n        3    0.000    0.000    0.000    0.000 {built-in method builtins.iter}\n        1    0.000    0.000    0.000    0.000 {method 'match' of '_sre.SRE_Pattern' objects}\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/singleton.py:9(__call__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:207(ensure_connection)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:437(validate_no_atomic_block)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:42(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:44(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:148(_accept)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1528(getEffectiveLevel)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:67(__enter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/urllib/parse.py:600(unquote)\n        1    0.000    0.000    0.000    0.000 {method 'endswith' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method _thread.get_ident}\n        1    0.000    0.000    0.000    0.000 {method 'disable' of '_lsprof.Profiler' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/http/cookies.py:504(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:70(__exit__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:36(_recreate_cm)\n        1    0.000    0.000    0.000    0.000 {method 'lstrip' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {method 'end' of '_sre.SRE_Match' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISDIR}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISREG}\n\n\n	0	
bdd3bea2-f2eb-4522-8aab-2bd26fcdd0ad	/media/test_annotations/8c8fc5ba-2a69-4063-b425-0d33368b857b.txt				GET	2020-06-05 17:50:51.264122+00	django.views.static.serve	2020-06-05 17:50:51.28536+00	21.2379999999999995	{"CONTENT-LENGTH": "", "CONTENT-TYPE": "text/plain", "HOST": "django:8000", "USER-AGENT": "python-requests/2.23.0", "ACCEPT-ENCODING": "gzip, deflate", "ACCEPT": "*/*", "CONNECTION": "keep-alive"}	\N	\N	\N	         349 function calls (332 primitive calls) in 0.001 seconds\n\n   Ordered by: cumulative time\n\n   ncalls  tottime  percall  cumtime  percall filename:lineno(function)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/site-packages/django/core/handlers/exception.py:38(inner)\n        1    0.000    0.000    0.001    0.001 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:157(_get_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/views/static.py:23(serve)\n     17/1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:358(resolve)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:131(process_response)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:49(inner)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:54(safe_join)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:371(__init__)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:150(__setitem__)\n        8    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:191(resolve)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/http.py:133(http_date)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:138(formatdate)\n        3    0.000    0.000    0.000    0.000 {built-in method posix.stat}\n       25    0.000    0.000    0.000    0.000 {method 'search' of '_sre.SRE_Pattern' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/mimetypes.py:271(guess_type)\n        1    0.000    0.000    0.000    0.000 {built-in method io.open}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/middleware.py:106(_process_response)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:331(normpath)\n        6    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:114(_convert_to_charset)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:39(isdir)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/mimetypes.py:97(guess_type)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:41(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:151(__enter__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:369(abspath)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:167(format_datetime)\n       19    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/encoding.py:58(force_text)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:34(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/core/handlers/base.py:109(make_view_atomic)\n      9/8    0.000    0.000    0.000    0.000 {built-in method builtins.getattr}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/middleware.py:93(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:121(splitext)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:225(all)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:388(streaming_content)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:388(set_autocommit)\n        1    0.000    0.000    0.000    0.000 {method 'timetuple' of 'datetime.datetime' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/debug_toolbar/middleware.py:82(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/corsheaders/conf.py:51(CORS_REPLACE_HTTPS_REFERER)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:411(_set_streaming_content)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:31(__enter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:75(join)\n       33    0.000    0.000    0.000    0.000 {built-in method builtins.isinstance}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:16(exists)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/genericpath.py:117(_splitext)\n       10    0.000    0.000    0.000    0.000 {built-in method builtins.hasattr}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:27(_should_meta_profile)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/email/utils.py:129(_format_timetuple_and_zone)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/urllib/parse.py:932(splittype)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:210(process_view)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1284(debug)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/postgresql/base.py:234(_set_autocommit)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:226(<listcomp>)\n       32    0.000    0.000    0.000    0.000 {method 'append' of 'list' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/collector.py:140(stop_python_profiler)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:204(__getitem__)\n        1    0.000    0.000    0.000    0.000 {built-in method fromtimestamp}\n       19    0.000    0.000    0.000    0.000 {method 'get' of 'dict' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/views/static.py:113(was_modified_since)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1542(isEnabledFor)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/transaction.py:14(get_connection)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1230(current_thread)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:64(isabs)\n        9    0.000    0.000    0.000    0.000 {method 'startswith' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/profiling/profiler.py:23(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:222(__iter__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/conf/__init__.py:51(__getattr__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:52(normcase)\n       11    0.000    0.000    0.000    0.000 {method 'join' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:381(get_autocommit)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/http/response.py:392(_set_streaming_content)\n        4    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:57(__getitem__)\n        3    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/posixpath.py:41(_get_sep)\n        6    0.000    0.000    0.000    0.000 {method 'encode' of 'str' objects}\n       19    0.000    0.000    0.000    0.000 {built-in method builtins.issubclass}\n        1    0.000    0.000    0.000    0.000 {method 'match' of '_sre.SRE_Pattern' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/config.py:43(__getattr__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/logging/__init__.py:1528(getEffectiveLevel)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/utils/_os.py:63(<listcomp>)\n        2    0.000    0.000    0.000    0.000 {method 'update' of 'dict' objects}\n        3    0.000    0.000    0.000    0.000 {method 'split' of 'str' objects}\n        2    0.000    0.000    0.000    0.000 {method 'rfind' of 'str' objects}\n        2    0.000    0.000    0.000    0.000 {method 'groupdict' of '_sre.SRE_Match' objects}\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/silk/singleton.py:9(__call__)\n        2    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:207(ensure_connection)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/urllib/parse.py:600(unquote)\n        3    0.000    0.000    0.000    0.000 {method 'lower' of 'str' objects}\n        3    0.000    0.000    0.000    0.000 {built-in method builtins.iter}\n       11    0.000    0.000    0.000    0.000 {built-in method posix.fspath}\n        1    0.000    0.000    0.000    0.000 {method 'disable' of '_lsprof.Profiler' objects}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/backends/base/base.py:437(validate_no_atomic_block)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/http/cookies.py:504(__init__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:42(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/urls/resolvers.py:44(<listcomp>)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:70(__exit__)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/threading.py:1092(ident)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/contextlib.py:36(_recreate_cm)\n        1    0.000    0.000    0.000    0.000 {method 'lstrip' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {method 'endswith' of 'str' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method _thread.get_ident}\n        1    0.000    0.000    0.000    0.000 {method 'end' of '_sre.SRE_Match' objects}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISDIR}\n        1    0.000    0.000    0.000    0.000 {built-in method _stat.S_ISREG}\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/middleware/csrf.py:148(_accept)\n        1    0.000    0.000    0.000    0.000 /usr/local/lib/python3.6/site-packages/django/db/utils.py:67(__enter__)\n\n\n	0	
\.


--
-- Data for Name: silk_response; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silk_response (id, status_code, raw_body, body, encoded_headers, request_id) FROM stdin;
5f6d905d-06fc-4d0e-a061-e2083ef771b1	200			{"Content-Type": "application/zip", "Last-Modified": "Fri, 05 Jun 2020 17:50:38 GMT", "Content-Length": "1164"}	ad73d218-5056-43ab-afb1-87c6b2dca0a0
4c63bb2c-e7d6-45cd-96ca-a4f294c0b2f1	200			{"Content-Type": "text/plain", "Last-Modified": "Fri, 05 Jun 2020 17:50:38 GMT", "Content-Length": "21"}	545d1368-56a2-4c88-86e8-026c6b47ba34
712d9d86-adaf-4049-bd32-61e0f117d7cd	200			{"Content-Type": "text/plain", "Last-Modified": "Fri, 05 Jun 2020 17:50:38 GMT", "Content-Length": "21"}	bdd3bea2-f2eb-4522-8aab-2bd26fcdd0ad
\.


--
-- Data for Name: silk_sqlquery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.silk_sqlquery (id, query, start_time, end_time, time_taken, traceback, request_id) FROM stdin;
\.


--
-- Data for Name: starred_challenge; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.starred_challenge (id, created_at, modified_at, challenge_id, user_id, is_starred) FROM stdin;
\.


--
-- Data for Name: submission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.submission (id, created_at, modified_at, status, is_public, submission_number, download_count, submitted_at, started_at, completed_at, when_made_public, input_file, stdout_file, stderr_file, challenge_phase_id, created_by_id, participant_team_id, execution_time_limit, output, method_name, method_description, project_url, publication_url, submission_metadata_file, submission_result_file, is_flagged, is_baseline, job_name) FROM stdin;
1	2020-06-05 17:50:38.287624+00	2020-06-05 17:50:38.306674+00	finished	t	1	0	2020-06-05 17:50:38.288089+00	2020-06-05 17:50:38.249169+00	2020-06-05 17:50:38.249174+00	\N	submission_files/submission_1/7046061c-a110-4936-97e7-1fd645273689.txt			1	3	1	300	[{'split1': {'score': 0}}, {'split2': {'score': 0}}]	Jessica	Fuga perspiciatis praesentium maiores nam. Dolor quis ea quos quod voluptates ab. Ratione minus dolore eum repellendus accusamus. Asperiores similique optio explicabo sunt repellendus quo distinctio enim.	https://clark.biz/post.php	https://salazar-ford.com/list/wp-content/tags/search.jsp			f	t	{}
2	2020-06-05 17:50:38.366977+00	2020-06-05 17:50:38.378785+00	finished	t	1	0	2020-06-05 17:50:38.367158+00	2020-06-05 17:50:38.33971+00	2020-06-05 17:50:38.339717+00	\N	submission_files/submission_2/89e6303b-0019-4423-93ff-998f4e37c57e.txt			2	3	1	300	[{'split1': {'score': 0}}, {'split2': {'score': 0}}]	Nicole	Provident aperiam atque sunt laudantium cum. Ipsam alias ex earum dolores dolores maxime vitae. Ea excepturi aut molestiae asperiores. Nulla sed distinctio ullam ratione enim.	http://christian.com/index/	http://stevens.com/search/wp-content/faq/			f	t	{}
\.


--
-- Data for Name: subscribers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscribers (id, created_at, modified_at, email) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, name, email, headshot, visible, github_url, linkedin_url, personal_website, team_type, background_image, description, "position") FROM stdin;
\.


--
-- Data for Name: user_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_profile (id, created_at, modified_at, contact_number, affiliation, receive_participated_challenge_updates, recieve_newsletter, user_id, github_url, google_scholar_url, linkedin_url) FROM stdin;
1	2020-06-05 17:50:38.024156+00	2020-06-05 17:50:38.024256+00	\N		f	f	1	\N	\N	\N
2	2020-06-05 17:50:38.082087+00	2020-06-05 17:50:38.082123+00	\N		f	f	2	\N	\N	\N
3	2020-06-05 17:50:38.187795+00	2020-06-05 17:50:38.187903+00	\N		f	f	3	\N	\N	\N
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 3, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: accounts_userstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_userstatus_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 111, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 3, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: challenge_evaluation_cluster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_evaluation_cluster_id_seq', 1, false);


--
-- Name: challenge_host_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_host_id_seq', 1, true);


--
-- Name: challenge_host_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_host_teams_id_seq', 1, true);


--
-- Name: challenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_id_seq', 1, true);


--
-- Name: challenge_participant_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_participant_teams_id_seq', 1, false);


--
-- Name: challenge_phase_split_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_phase_split_id_seq', 4, true);


--
-- Name: challenge_test_env_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_test_env_id_seq', 2, true);


--
-- Name: challenge_zip_configuration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.challenge_zip_configuration_id_seq', 1, false);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_id_seq', 1, false);


--
-- Name: dataset_split_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dataset_split_id_seq', 2, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 37, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 135, true);


--
-- Name: django_ses_sesstat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_ses_sesstat_id_seq', 1, false);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: invite_user_to_challenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invite_user_to_challenge_id_seq', 1, false);


--
-- Name: leaderboard_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leaderboard_data_id_seq', 4, true);


--
-- Name: leaderboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leaderboard_id_seq', 1, true);


--
-- Name: participant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.participant_id_seq', 1, true);


--
-- Name: participant_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.participant_team_id_seq', 1, true);


--
-- Name: silk_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.silk_profile_id_seq', 1, false);


--
-- Name: silk_profile_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.silk_profile_queries_id_seq', 1, false);


--
-- Name: silk_sqlquery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.silk_sqlquery_id_seq', 1, false);


--
-- Name: starred_challenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.starred_challenge_id_seq', 1, false);


--
-- Name: submission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.submission_id_seq', 2, true);


--
-- Name: subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subscribers_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- Name: user_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_profile_id_seq', 3, true);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: accounts_userstatus accounts_userstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_userstatus
    ADD CONSTRAINT accounts_userstatus_pkey PRIMARY KEY (id);


--
-- Name: accounts_userstatus accounts_userstatus_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_userstatus
    ADD CONSTRAINT accounts_userstatus_status_key UNIQUE (status);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: challenge_evaluation_cluster challenge_evaluation_cluster_challenge_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_evaluation_cluster
    ADD CONSTRAINT challenge_evaluation_cluster_challenge_id_key UNIQUE (challenge_id);


--
-- Name: challenge_evaluation_cluster challenge_evaluation_cluster_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_evaluation_cluster
    ADD CONSTRAINT challenge_evaluation_cluster_name_key UNIQUE (name);


--
-- Name: challenge_evaluation_cluster challenge_evaluation_cluster_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_evaluation_cluster
    ADD CONSTRAINT challenge_evaluation_cluster_pkey PRIMARY KEY (id);


--
-- Name: challenge_host challenge_host_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host
    ADD CONSTRAINT challenge_host_pkey PRIMARY KEY (id);


--
-- Name: challenge_host_teams challenge_host_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host_teams
    ADD CONSTRAINT challenge_host_teams_pkey PRIMARY KEY (id);


--
-- Name: challenge_host_teams challenge_host_teams_team_name_a33ba416_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host_teams
    ADD CONSTRAINT challenge_host_teams_team_name_a33ba416_uniq UNIQUE (team_name);


--
-- Name: challenge_participant_teams challenge_participant_te_challenge_id_participant_105c59bd_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_participant_teams
    ADD CONSTRAINT challenge_participant_te_challenge_id_participant_105c59bd_uniq UNIQUE (challenge_id, participantteam_id);


--
-- Name: challenge_participant_teams challenge_participant_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_participant_teams
    ADD CONSTRAINT challenge_participant_teams_pkey PRIMARY KEY (id);


--
-- Name: challenge_phase challenge_phase_code_name_challenge_id_e2c8bf60_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase
    ADD CONSTRAINT challenge_phase_code_name_challenge_id_e2c8bf60_uniq UNIQUE (codename, challenge_id);


--
-- Name: challenge_phase challenge_phase_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase
    ADD CONSTRAINT challenge_phase_slug_key UNIQUE (slug);


--
-- Name: challenge_phase_split challenge_phase_split_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase_split
    ADD CONSTRAINT challenge_phase_split_pkey PRIMARY KEY (id);


--
-- Name: challenge challenge_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge
    ADD CONSTRAINT challenge_pkey PRIMARY KEY (id);


--
-- Name: challenge challenge_slug_9e574ab6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge
    ADD CONSTRAINT challenge_slug_9e574ab6_uniq UNIQUE (slug);


--
-- Name: challenge_phase challenge_test_env_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase
    ADD CONSTRAINT challenge_test_env_pkey PRIMARY KEY (id);


--
-- Name: challenge_zip_configuration challenge_zip_configuration_challenge_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_zip_configuration
    ADD CONSTRAINT challenge_zip_configuration_challenge_id_key UNIQUE (challenge_id);


--
-- Name: challenge_zip_configuration challenge_zip_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_zip_configuration
    ADD CONSTRAINT challenge_zip_configuration_pkey PRIMARY KEY (id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: dataset_split dataset_split_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dataset_split
    ADD CONSTRAINT dataset_split_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_ses_sesstat django_ses_sesstat_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_ses_sesstat
    ADD CONSTRAINT django_ses_sesstat_date_key UNIQUE (date);


--
-- Name: django_ses_sesstat django_ses_sesstat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_ses_sesstat
    ADD CONSTRAINT django_ses_sesstat_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: invite_user_to_challenge invite_user_to_challenge_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_user_to_challenge
    ADD CONSTRAINT invite_user_to_challenge_pkey PRIMARY KEY (id);


--
-- Name: leaderboard_data leaderboard_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_data
    ADD CONSTRAINT leaderboard_data_pkey PRIMARY KEY (id);


--
-- Name: leaderboard leaderboard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard
    ADD CONSTRAINT leaderboard_pkey PRIMARY KEY (id);


--
-- Name: participant participant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant
    ADD CONSTRAINT participant_pkey PRIMARY KEY (id);


--
-- Name: participant_team participant_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant_team
    ADD CONSTRAINT participant_team_pkey PRIMARY KEY (id);


--
-- Name: participant_team participant_team_team_name_f09a648b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant_team
    ADD CONSTRAINT participant_team_team_name_f09a648b_uniq UNIQUE (team_name);


--
-- Name: silk_profile silk_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile
    ADD CONSTRAINT silk_profile_pkey PRIMARY KEY (id);


--
-- Name: silk_profile_queries silk_profile_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile_queries
    ADD CONSTRAINT silk_profile_queries_pkey PRIMARY KEY (id);


--
-- Name: silk_profile_queries silk_profile_queries_profile_id_sqlquery_id_b2403d9b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile_queries
    ADD CONSTRAINT silk_profile_queries_profile_id_sqlquery_id_b2403d9b_uniq UNIQUE (profile_id, sqlquery_id);


--
-- Name: silk_request silk_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_request
    ADD CONSTRAINT silk_request_pkey PRIMARY KEY (id);


--
-- Name: silk_response silk_response_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_response
    ADD CONSTRAINT silk_response_pkey PRIMARY KEY (id);


--
-- Name: silk_response silk_response_request_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_response
    ADD CONSTRAINT silk_response_request_id_key UNIQUE (request_id);


--
-- Name: silk_sqlquery silk_sqlquery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_sqlquery
    ADD CONSTRAINT silk_sqlquery_pkey PRIMARY KEY (id);


--
-- Name: starred_challenge starred_challenge_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starred_challenge
    ADD CONSTRAINT starred_challenge_pkey PRIMARY KEY (id);


--
-- Name: submission submission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_pkey PRIMARY KEY (id);


--
-- Name: subscribers subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscribers
    ADD CONSTRAINT subscribers_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: user_profile user_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_pkey PRIMARY KEY (id);


--
-- Name: user_profile user_profile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_user_id_key UNIQUE (user_id);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: accounts_userstatus_status_cf987dab_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_userstatus_status_cf987dab_like ON public.accounts_userstatus USING btree (status varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: challenge_approved_by_admin_48e7b5a6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_approved_by_admin_48e7b5a6 ON public.challenge USING btree (approved_by_admin);


--
-- Name: challenge_broker_url_574dd9b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_broker_url_574dd9b9 ON public.challenge USING btree (queue);


--
-- Name: challenge_broker_url_574dd9b9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_broker_url_574dd9b9_like ON public.challenge USING btree (queue varchar_pattern_ops);


--
-- Name: challenge_creator_id_6f914969; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_creator_id_6f914969 ON public.challenge USING btree (creator_id);


--
-- Name: challenge_end_date_82c36eaa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_end_date_82c36eaa ON public.challenge USING btree (end_date);


--
-- Name: challenge_evaluation_cluster_name_e3c52384_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_evaluation_cluster_name_e3c52384_like ON public.challenge_evaluation_cluster USING btree (name varchar_pattern_ops);


--
-- Name: challenge_featured_0e158d04; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_featured_0e158d04 ON public.challenge USING btree (featured);


--
-- Name: challenge_host_team_name_id_20d41d66; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_host_team_name_id_20d41d66 ON public.challenge_host USING btree (team_name_id);


--
-- Name: challenge_host_teams_created_by_id_c365316e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_host_teams_created_by_id_c365316e ON public.challenge_host_teams USING btree (created_by_id);


--
-- Name: challenge_host_teams_team_name_a33ba416_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_host_teams_team_name_a33ba416_like ON public.challenge_host_teams USING btree (team_name varchar_pattern_ops);


--
-- Name: challenge_host_user_id_6f7925ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_host_user_id_6f7925ca ON public.challenge_host USING btree (user_id);


--
-- Name: challenge_is_disabled_954ee37c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_is_disabled_954ee37c ON public.challenge USING btree (is_disabled);


--
-- Name: challenge_is_docker_based_9180d4cc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_is_docker_based_9180d4cc ON public.challenge USING btree (is_docker_based);


--
-- Name: challenge_participant_teams_challenge_id_b17b7a41; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_participant_teams_challenge_id_b17b7a41 ON public.challenge_participant_teams USING btree (challenge_id);


--
-- Name: challenge_participant_teams_participantteam_id_02fc1877; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_participant_teams_participantteam_id_02fc1877 ON public.challenge_participant_teams USING btree (participantteam_id);


--
-- Name: challenge_phase_end_date_25523574; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_end_date_25523574 ON public.challenge_phase USING btree (end_date);


--
-- Name: challenge_phase_max_submissions_aa7d89ee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_max_submissions_aa7d89ee ON public.challenge_phase USING btree (max_submissions);


--
-- Name: challenge_phase_max_submissions_per_day_956337f0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_max_submissions_per_day_956337f0 ON public.challenge_phase USING btree (max_submissions_per_day);


--
-- Name: challenge_phase_max_submissions_per_month_1e18a24f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_max_submissions_per_month_1e18a24f ON public.challenge_phase USING btree (max_submissions_per_month);


--
-- Name: challenge_phase_name_4bdd9d93; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_name_4bdd9d93 ON public.challenge_phase USING btree (name);


--
-- Name: challenge_phase_name_4bdd9d93_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_name_4bdd9d93_like ON public.challenge_phase USING btree (name varchar_pattern_ops);


--
-- Name: challenge_phase_slug_530ab4f3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_slug_530ab4f3_like ON public.challenge_phase USING btree (slug varchar_pattern_ops);


--
-- Name: challenge_phase_split_challenge_phase_id_79714f89; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_split_challenge_phase_id_79714f89 ON public.challenge_phase_split USING btree (challenge_phase_id);


--
-- Name: challenge_phase_split_dataset_split_id_4a80cedc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_split_dataset_split_id_4a80cedc ON public.challenge_phase_split USING btree (dataset_split_id);


--
-- Name: challenge_phase_split_leaderboard_id_10ab4c12; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_split_leaderboard_id_10ab4c12 ON public.challenge_phase_split USING btree (leaderboard_id);


--
-- Name: challenge_phase_start_date_29d7398f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_phase_start_date_29d7398f ON public.challenge_phase USING btree (start_date);


--
-- Name: challenge_published_2d3a649e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_published_2d3a649e ON public.challenge USING btree (published);


--
-- Name: challenge_remote_evaluation_7eda0263; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_remote_evaluation_7eda0263 ON public.challenge USING btree (remote_evaluation);


--
-- Name: challenge_slug_9e574ab6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_slug_9e574ab6_like ON public.challenge USING btree (slug varchar_pattern_ops);


--
-- Name: challenge_start_date_390bb257; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_start_date_390bb257 ON public.challenge USING btree (start_date);


--
-- Name: challenge_test_env_challenge_id_c4d0c967; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_test_env_challenge_id_c4d0c967 ON public.challenge_phase USING btree (challenge_id);


--
-- Name: challenge_title_c79fd5ab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_title_c79fd5ab ON public.challenge USING btree (title);


--
-- Name: challenge_title_c79fd5ab_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_title_c79fd5ab_like ON public.challenge USING btree (title varchar_pattern_ops);


--
-- Name: challenge_zip_configuration_is_created_98afe0f7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_zip_configuration_is_created_98afe0f7 ON public.challenge_zip_configuration USING btree (is_created);


--
-- Name: challenge_zip_configuration_user_id_650dcae6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX challenge_zip_configuration_user_id_650dcae6 ON public.challenge_zip_configuration USING btree (user_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: invite_user_to_challenge_challenge_id_91cce4e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invite_user_to_challenge_challenge_id_91cce4e3 ON public.invite_user_to_challenge USING btree (challenge_id);


--
-- Name: invite_user_to_challenge_invited_by_id_9dbf46e4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invite_user_to_challenge_invited_by_id_9dbf46e4 ON public.invite_user_to_challenge USING btree (invited_by_id);


--
-- Name: invite_user_to_challenge_status_bd84ab61; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invite_user_to_challenge_status_bd84ab61 ON public.invite_user_to_challenge USING btree (status);


--
-- Name: invite_user_to_challenge_status_bd84ab61_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invite_user_to_challenge_status_bd84ab61_like ON public.invite_user_to_challenge USING btree (status varchar_pattern_ops);


--
-- Name: invite_user_to_challenge_user_id_8cec7728; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX invite_user_to_challenge_user_id_8cec7728 ON public.invite_user_to_challenge USING btree (user_id);


--
-- Name: leaderboard_data_challenge_phase_split_id_a7b9b5f3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leaderboard_data_challenge_phase_split_id_a7b9b5f3 ON public.leaderboard_data USING btree (challenge_phase_split_id);


--
-- Name: leaderboard_data_leaderboard_id_9a2a4e71; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leaderboard_data_leaderboard_id_9a2a4e71 ON public.leaderboard_data USING btree (leaderboard_id);


--
-- Name: leaderboard_data_submission_id_94de5dcd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX leaderboard_data_submission_id_94de5dcd ON public.leaderboard_data USING btree (submission_id);


--
-- Name: participant_team_created_by_id_198e1fba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX participant_team_created_by_id_198e1fba ON public.participant_team USING btree (created_by_id);


--
-- Name: participant_team_id_11757b04; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX participant_team_id_11757b04 ON public.participant USING btree (team_id);


--
-- Name: participant_team_team_name_f09a648b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX participant_team_team_name_f09a648b_like ON public.participant_team USING btree (team_name varchar_pattern_ops);


--
-- Name: participant_user_id_8d68cba9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX participant_user_id_8d68cba9 ON public.participant USING btree (user_id);


--
-- Name: silk_profile_queries_profile_id_a3d76db8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_profile_queries_profile_id_a3d76db8 ON public.silk_profile_queries USING btree (profile_id);


--
-- Name: silk_profile_queries_sqlquery_id_155df455; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_profile_queries_sqlquery_id_155df455 ON public.silk_profile_queries USING btree (sqlquery_id);


--
-- Name: silk_profile_request_id_7b81bd69; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_profile_request_id_7b81bd69 ON public.silk_profile USING btree (request_id);


--
-- Name: silk_profile_request_id_7b81bd69_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_profile_request_id_7b81bd69_like ON public.silk_profile USING btree (request_id varchar_pattern_ops);


--
-- Name: silk_request_id_5a356c4f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_id_5a356c4f_like ON public.silk_request USING btree (id varchar_pattern_ops);


--
-- Name: silk_request_path_9f3d798e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_path_9f3d798e ON public.silk_request USING btree (path);


--
-- Name: silk_request_path_9f3d798e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_path_9f3d798e_like ON public.silk_request USING btree (path varchar_pattern_ops);


--
-- Name: silk_request_start_time_1300bc58; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_start_time_1300bc58 ON public.silk_request USING btree (start_time);


--
-- Name: silk_request_view_name_68559f7b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_view_name_68559f7b ON public.silk_request USING btree (view_name);


--
-- Name: silk_request_view_name_68559f7b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_request_view_name_68559f7b_like ON public.silk_request USING btree (view_name varchar_pattern_ops);


--
-- Name: silk_response_id_dda88710_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_response_id_dda88710_like ON public.silk_response USING btree (id varchar_pattern_ops);


--
-- Name: silk_response_request_id_1e8e2776_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_response_request_id_1e8e2776_like ON public.silk_response USING btree (request_id varchar_pattern_ops);


--
-- Name: silk_sqlquery_request_id_6f8f0527; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_sqlquery_request_id_6f8f0527 ON public.silk_sqlquery USING btree (request_id);


--
-- Name: silk_sqlquery_request_id_6f8f0527_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX silk_sqlquery_request_id_6f8f0527_like ON public.silk_sqlquery USING btree (request_id varchar_pattern_ops);


--
-- Name: starred_challenge_challenge_id_4f2e3f0a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX starred_challenge_challenge_id_4f2e3f0a ON public.starred_challenge USING btree (challenge_id);


--
-- Name: starred_challenge_is_starred_073a763f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX starred_challenge_is_starred_073a763f ON public.starred_challenge USING btree (is_starred);


--
-- Name: starred_challenge_user_id_e1f238f0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX starred_challenge_user_id_e1f238f0 ON public.starred_challenge USING btree (user_id);


--
-- Name: submission_challenge_phase_id_9421c7ab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_challenge_phase_id_9421c7ab ON public.submission USING btree (challenge_phase_id);


--
-- Name: submission_completed_at_94fbcc73; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_completed_at_94fbcc73 ON public.submission USING btree (completed_at);


--
-- Name: submission_created_by_id_f8333be6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_created_by_id_f8333be6 ON public.submission USING btree (created_by_id);


--
-- Name: submission_method_name_519c4c5f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_method_name_519c4c5f ON public.submission USING btree (method_name);


--
-- Name: submission_method_name_519c4c5f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_method_name_519c4c5f_like ON public.submission USING btree (method_name varchar_pattern_ops);


--
-- Name: submission_participant_team_id_409973b4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_participant_team_id_409973b4 ON public.submission USING btree (participant_team_id);


--
-- Name: submission_started_at_281177d5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_started_at_281177d5 ON public.submission USING btree (started_at);


--
-- Name: submission_status_113026cb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_status_113026cb ON public.submission USING btree (status);


--
-- Name: submission_status_113026cb_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_status_113026cb_like ON public.submission USING btree (status varchar_pattern_ops);


--
-- Name: submission_submitted_at_16e9ee45; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX submission_submitted_at_16e9ee45 ON public.submission USING btree (submitted_at);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge challenge_creator_id_6f914969_fk_challenge_host_teams_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge
    ADD CONSTRAINT challenge_creator_id_6f914969_fk_challenge_host_teams_id FOREIGN KEY (creator_id) REFERENCES public.challenge_host_teams(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_evaluation_cluster challenge_evaluation_challenge_id_f381bfc8_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_evaluation_cluster
    ADD CONSTRAINT challenge_evaluation_challenge_id_f381bfc8_fk_challenge FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_host challenge_host_team_name_id_20d41d66_fk_challenge_host_teams_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host
    ADD CONSTRAINT challenge_host_team_name_id_20d41d66_fk_challenge_host_teams_id FOREIGN KEY (team_name_id) REFERENCES public.challenge_host_teams(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_host_teams challenge_host_teams_created_by_id_c365316e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host_teams
    ADD CONSTRAINT challenge_host_teams_created_by_id_c365316e_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_host challenge_host_user_id_6f7925ca_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_host
    ADD CONSTRAINT challenge_host_user_id_6f7925ca_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_participant_teams challenge_participan_challenge_id_b17b7a41_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_participant_teams
    ADD CONSTRAINT challenge_participan_challenge_id_b17b7a41_fk_challenge FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_participant_teams challenge_participan_participantteam_id_02fc1877_fk_participa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_participant_teams
    ADD CONSTRAINT challenge_participan_participantteam_id_02fc1877_fk_participa FOREIGN KEY (participantteam_id) REFERENCES public.participant_team(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_phase_split challenge_phase_spli_challenge_phase_id_79714f89_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase_split
    ADD CONSTRAINT challenge_phase_spli_challenge_phase_id_79714f89_fk_challenge FOREIGN KEY (challenge_phase_id) REFERENCES public.challenge_phase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_phase_split challenge_phase_spli_dataset_split_id_4a80cedc_fk_dataset_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase_split
    ADD CONSTRAINT challenge_phase_spli_dataset_split_id_4a80cedc_fk_dataset_s FOREIGN KEY (dataset_split_id) REFERENCES public.dataset_split(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_phase_split challenge_phase_split_leaderboard_id_10ab4c12_fk_leaderboard_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase_split
    ADD CONSTRAINT challenge_phase_split_leaderboard_id_10ab4c12_fk_leaderboard_id FOREIGN KEY (leaderboard_id) REFERENCES public.leaderboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_phase challenge_test_env_challenge_id_c4d0c967_fk_challenge_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_phase
    ADD CONSTRAINT challenge_test_env_challenge_id_c4d0c967_fk_challenge_id FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_zip_configuration challenge_zip_config_challenge_id_f138cd0e_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_zip_configuration
    ADD CONSTRAINT challenge_zip_config_challenge_id_f138cd0e_fk_challenge FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: challenge_zip_configuration challenge_zip_configuration_user_id_650dcae6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challenge_zip_configuration
    ADD CONSTRAINT challenge_zip_configuration_user_id_650dcae6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invite_user_to_challenge invite_user_to_chall_invited_by_id_9dbf46e4_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_user_to_challenge
    ADD CONSTRAINT invite_user_to_chall_invited_by_id_9dbf46e4_fk_challenge FOREIGN KEY (invited_by_id) REFERENCES public.challenge_host(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invite_user_to_challenge invite_user_to_challenge_challenge_id_91cce4e3_fk_challenge_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_user_to_challenge
    ADD CONSTRAINT invite_user_to_challenge_challenge_id_91cce4e3_fk_challenge_id FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: invite_user_to_challenge invite_user_to_challenge_user_id_8cec7728_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite_user_to_challenge
    ADD CONSTRAINT invite_user_to_challenge_user_id_8cec7728_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: leaderboard_data leaderboard_data_challenge_phase_spli_a7b9b5f3_fk_challenge; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_data
    ADD CONSTRAINT leaderboard_data_challenge_phase_spli_a7b9b5f3_fk_challenge FOREIGN KEY (challenge_phase_split_id) REFERENCES public.challenge_phase_split(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: leaderboard_data leaderboard_data_leaderboard_id_9a2a4e71_fk_leaderboard_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_data
    ADD CONSTRAINT leaderboard_data_leaderboard_id_9a2a4e71_fk_leaderboard_id FOREIGN KEY (leaderboard_id) REFERENCES public.leaderboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: leaderboard_data leaderboard_data_submission_id_94de5dcd_fk_submission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_data
    ADD CONSTRAINT leaderboard_data_submission_id_94de5dcd_fk_submission_id FOREIGN KEY (submission_id) REFERENCES public.submission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: participant_team participant_team_created_by_id_198e1fba_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant_team
    ADD CONSTRAINT participant_team_created_by_id_198e1fba_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: participant participant_team_id_11757b04_fk_participant_team_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant
    ADD CONSTRAINT participant_team_id_11757b04_fk_participant_team_id FOREIGN KEY (team_id) REFERENCES public.participant_team(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: participant participant_user_id_8d68cba9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant
    ADD CONSTRAINT participant_user_id_8d68cba9_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: silk_profile_queries silk_profile_queries_profile_id_a3d76db8_fk_silk_profile_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile_queries
    ADD CONSTRAINT silk_profile_queries_profile_id_a3d76db8_fk_silk_profile_id FOREIGN KEY (profile_id) REFERENCES public.silk_profile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: silk_profile_queries silk_profile_queries_sqlquery_id_155df455_fk_silk_sqlquery_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile_queries
    ADD CONSTRAINT silk_profile_queries_sqlquery_id_155df455_fk_silk_sqlquery_id FOREIGN KEY (sqlquery_id) REFERENCES public.silk_sqlquery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: silk_profile silk_profile_request_id_7b81bd69_fk_silk_request_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_profile
    ADD CONSTRAINT silk_profile_request_id_7b81bd69_fk_silk_request_id FOREIGN KEY (request_id) REFERENCES public.silk_request(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: silk_response silk_response_request_id_1e8e2776_fk_silk_request_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_response
    ADD CONSTRAINT silk_response_request_id_1e8e2776_fk_silk_request_id FOREIGN KEY (request_id) REFERENCES public.silk_request(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: silk_sqlquery silk_sqlquery_request_id_6f8f0527_fk_silk_request_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.silk_sqlquery
    ADD CONSTRAINT silk_sqlquery_request_id_6f8f0527_fk_silk_request_id FOREIGN KEY (request_id) REFERENCES public.silk_request(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: starred_challenge starred_challenge_challenge_id_4f2e3f0a_fk_challenge_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starred_challenge
    ADD CONSTRAINT starred_challenge_challenge_id_4f2e3f0a_fk_challenge_id FOREIGN KEY (challenge_id) REFERENCES public.challenge(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: starred_challenge starred_challenge_user_id_e1f238f0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.starred_challenge
    ADD CONSTRAINT starred_challenge_user_id_e1f238f0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: submission submission_challenge_phase_id_9421c7ab_fk_challenge_phase_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_challenge_phase_id_9421c7ab_fk_challenge_phase_id FOREIGN KEY (challenge_phase_id) REFERENCES public.challenge_phase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: submission submission_created_by_id_f8333be6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_created_by_id_f8333be6_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: submission submission_participant_team_id_409973b4_fk_participant_team_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission
    ADD CONSTRAINT submission_participant_team_id_409973b4_fk_participant_team_id FOREIGN KEY (participant_team_id) REFERENCES public.participant_team(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_profile user_profile_user_id_8fdce8e2_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_user_id_8fdce8e2_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

